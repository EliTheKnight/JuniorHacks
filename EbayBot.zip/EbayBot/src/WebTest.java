import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlForm;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlTextInput;
import com.gargoylesoftware.htmlunit.javascript.host.event.Event;
import com.gargoylesoftware.htmlunit.javascript.host.event.KeyboardEvent;

public class WebTest {
    public static void main(String[] args) {

            try {
                WebClient webClient = new WebClient(BrowserVersion.CHROME);

                webClient.getOptions().setJavaScriptEnabled(false);

                HtmlPage page = webClient.getPage("https://www.pokemonprice.com/");

                String pageText = page.asNormalizedText();
                String pageXml = page.asXml();

                HtmlForm form = page.getForms().get(0);
                String formtext = form.asXml();
                HtmlTextInput textField = form.getInputByName("searchterm");
                textField.type("pikachu");
                System.out.println(formtext);

//                System.out.println(pageXml);




        }catch (Exception e){e.printStackTrace();}
    }
}
